# graphics

Graphics infrastructure for CIS 211, Winter 2018 at University of Oregon; fork of Zelle's graphics.py

Initially this contains just a copy of Zelle's graphics.py.  It is
unclear what I may add, and whether or not I may make some revisions
to Zelle's graphics library.  Starting point is graphics.py
version 5.0, forked December 2017.

As Zelle's module is open-sourced as GPL, I have adopted GPL for this
repo.

Putting this in a subdirectory of a student project, graphics can be
imported with

```python
import graphics.grapics as graphics
```
